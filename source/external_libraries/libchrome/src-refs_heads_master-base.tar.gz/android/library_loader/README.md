# //base/android/library_loader

Native code is split between this directory and:
 * [//third_party/android_crazy_linker](../../../third_party/android_crazy_linker/README.chromium)

Java code lives at:
 * [//base/android/java/src/org/chromium/base/library_loader/](../java/src/org/chromium/base/library_loader/)

A high-level guide to native code on Android exists at:
 * [//docs/android_native_libraries.md](../../../docs/android_native_libraries.md)
